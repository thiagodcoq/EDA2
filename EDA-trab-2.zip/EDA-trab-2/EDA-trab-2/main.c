//
//  arvore.c
//  EDA-trab-2
//
//  Created by Sofia Porto e Thiago Coqueiro on 25/04/25.
//

#include <stdio.h>
#include "arvore.h"

int main(void) {
    // Questão 1a: Árvore original
    printf("\n--- Questao 1a: Arvore original ---\n");
    Node *root1a = monta_arvore();
    printf("\nPre-ordem:\n");
    exibe_preordem(root1a);
    printf("\nSimetrica:\n");
    exibe_simetrica(root1a);
    printf("\nVerificacao ABB: %s\n", isABB(root1a) ? "Eh ABB" : "Nao eh ABB");
    printf("Verificacao AVL: %s\n", verificaAVL(root1a) ? "Eh AVL" : "Nao eh AVL");
    libera_arvore(root1a);
    
    // Questão 1b: Árvore sem o nó 1
    printf("\n\n--- Questao 1b: Arvore sem o no 1 ---\n");
    Node *root1b = monta_arvore();
    deleta(1, &root1b);
    printf("\nPre-ordem:\n");
    exibe_preordem(root1b);
    printf("\nSimetrica:\n");
    exibe_simetrica(root1b);
    printf("\nVerificacao ABB: %s\n", isABB(root1b) ? "Eh ABB" : "Nao eh ABB");
    printf("Verificacao AVL: %s\n", verificaAVL(root1b) ? "Eh AVL" : "Nao eh AVL");
    libera_arvore(root1b);
    
    // Questão 1c: Árvore trocando 22 por 17
    printf("\n\n--- Questao 1c: Arvore trocando 22 por 17 ---\n");
    Node *root1c = monta_arvore();
    troca_valor(root1c, 22, 17);
    printf("\nPre-ordem:\n");
    exibe_preordem(root1c);
    printf("\nSimetrica:\n");
    exibe_simetrica(root1c);
    printf("\nVerificacao ABB: %s\n", isABB(root1c) ? "Eh ABB" : "Nao eh ABB");
    printf("Verificacao AVL: %s\n", verificaAVL(root1c) ? "Eh AVL" : "Nao eh AVL");
    libera_arvore(root1c);
    
    // Questão 2: Árvore construída por nível
    printf("\n\n--- Questao 2: Arvore construída por nivel ---\n");
    Node *root2 = monta_arvore_nivel();
    printf("\nPre-ordem:\n");
    exibe_preordem(root2);
    printf("\nSimetrica:\n");
    exibe_simetrica(root2);
    libera_arvore(root2);
    
    return 0;
}
