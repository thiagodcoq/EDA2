//
//  arvore.c
//  EDA-trab-2
//
//  Created by Sofia Porto e Thiago Coqueiro on 26/04/25.
//

#include <stdio.h>
#include <stdlib.h>
#include "arvore.h"

///Funções de Fila
Fila* criaFila(void) {
    Fila* q = (Fila*)malloc(sizeof(Fila));
    if (q == NULL) {
        printf("Erro: Falha na alocação de memória para a fila\n");
        exit(1);
    }
    q->frente = q->tras = NULL;
    return q;
}

int fila_vazia(Fila *q) {
    if (q == NULL) {
        printf("Erro: Fila nula\n");
        exit(1);
    }
    return q->frente == NULL;
}

void enqueue(Fila *q, Node *node) {
    if (q == NULL || node == NULL) {
        printf("Erro: Fila ou nó nulo\n");
        exit(1);
    }
    NodeFila* novoNode = (NodeFila*)malloc(sizeof(NodeFila));
    if (novoNode == NULL) {
        printf("Erro: Falha na alocação de memória para o nó da fila\n");
        exit(1);
    }
    novoNode->node = node;
    novoNode->prox = NULL;
    
    if (q->tras == NULL) {
        q->frente = q->tras = novoNode;
    } else {
        q->tras->prox = novoNode;
        q->tras = novoNode;
    }
}

Node* dequeue(Fila *q) {
    if (q == NULL) {
        printf("Erro: Fila nula\n");
        exit(1);
    }
    if (fila_vazia(q)) {
        printf("Erro: Fila vazia\n");
        exit(1);
    }
    NodeFila *temp = q->frente;
    Node *node = temp->node;
    q->frente = q->frente->prox;
    
    if (q->frente == NULL) {
        q->tras = NULL;
    }
    free(temp);
    return node;
}

void fila_libera(Fila *q) {
    if (q == NULL) return;
    while (!fila_vazia(q)) {
        dequeue(q);
    }
    free(q);
}

///Funções de Árvore
Node *node_cria(int value) {
    Node *new = (Node *)malloc(sizeof(Node));
    if (new == NULL) {
        printf("Erro: Falha na alocação de memória\n");
        exit(1);
    }
    new->chave = value;
    new->esq = NULL;
    new->dir = NULL;
    return new;
}

Node *monta_arvore(void) {
    Node *no6 = node_cria(6);
    Node *no8 = node_cria(8);
    Node *no11 = node_cria(11);
    Node *no22 = node_cria(22);
    Node *no1 = node_cria(1);
    
    Node *no7 = node_cria(7);
    no7->esq = no6;
    no7->dir = no8;
    
    Node *no15 = node_cria(15);
    no15->esq = no11;
    
    Node *no21 = node_cria(21);
    no21->dir = no22;
    
    Node *no5 = node_cria(5);
    no5->esq = no1;
    no5->dir = no7;
    
    Node *no20 = node_cria(20);
    no20->esq = no15;
    no20->dir = no21;
    
    Node *root = node_cria(10);
    root->esq = no5;
    root->dir = no20;
    
    return root;
}

Node* monta_arvore_nivel(void) {
    int values[] = {10, 5, 20, 1, 7, 15, 21, 6, 8, 11, 22};
    
    Node *root = node_cria(values[0]);
    Fila *q = criaFila();
    enqueue(q, root);
    
    Node *no10 = dequeue(q);
    
    no10->esq = node_cria(values[1]);
    no10->dir = node_cria(values[2]);
    enqueue(q, no10->esq);
    enqueue(q, no10->dir);
    
    Node *no5 = dequeue(q);
    Node *no20 = dequeue(q);
    
    no5->esq = node_cria(values[3]);
    no5->dir = node_cria(values[4]);
    no20->esq = node_cria(values[5]);
    no20->dir = node_cria(values[6]);
    
    enqueue(q, no5->esq);
    enqueue(q, no5->dir);
    enqueue(q, no20->esq);
    enqueue(q, no20->dir);
    
    Node *no1 = dequeue(q);
    Node *no7 = dequeue(q);
    Node *no15 = dequeue(q);
    Node *no21 = dequeue(q);
    
    no7->esq = node_cria(values[7]);
    no7->dir = node_cria(values[8]);
    no15->esq = node_cria(values[9]);
    no21->dir = node_cria(values[10]);
    
    fila_libera(q);
    return root;
}

void exibe_preordem(Node *root) {
    if (root == NULL) {
        printf("arvore nao foi criada\n");
        return;
    }
    printf("ptr_no=%p, chave=%d esq=%p dir=%p\n", root, root->chave, root->esq, root->dir);
    if (root->esq != NULL)
        exibe_preordem(root->esq);
    if (root->dir != NULL)
        exibe_preordem(root->dir);
}

void exibe_simetrica(Node *p) {
    if (p == NULL) {
        printf("arvore nao foi criada\n");
        return;
    }
    if (p->esq != NULL)
        exibe_simetrica(p->esq);
    printf("ptr_no=%p, chave=%d esq=%p dir=%p\n", p, p->chave, p->esq, p->dir);
    if (p->dir != NULL)
        exibe_simetrica(p->dir);
}

int deletamin(Node**pt) {
    int min;
    Node*aux;
    if ((*pt)->esq == NULL) {
        min = (*pt)->chave;
        aux = (*pt);
        (*pt) = (*pt)->dir;
        free(aux);
        return min;
    }
    return deletamin(&((*pt)->esq));
}

void deleta(int x, Node**pt) {
    Node* aux;
    if ((*pt) != NULL)
        if (x < (*pt)->chave) {
            deleta(x, &((*pt)->esq));
        } else {
            if (x > (*pt)->chave) {
                deleta(x, &((*pt)->dir));
            } else {
                if ((*pt)->esq == NULL) {
                    aux = (*pt);
                    (*pt) = (*pt)->dir;
                    free(aux);
                }
                else if ((*pt)->dir == NULL) {
                    aux = (*pt);
                    (*pt) = (*pt)->esq;
                    free(aux);
                }
                else
                    (*pt)->chave = deletamin(&((*pt)->dir));
            }
        }
}

void libera_arvore(Node *root) {
    if (root == NULL) {
        return;
    }
    libera_arvore(root->esq);
    libera_arvore(root->dir);
    free(root);
}

void troca_valor(Node *root, int antigo, int novo) {
    if (root == NULL)
        return;
    
    if (root->chave == antigo)
        root->chave = novo;
    
    troca_valor(root->esq, antigo, novo);
    troca_valor(root->dir, antigo, novo);
}

///Funções de Verificação
int verificaABB(Node *p, int *ultimo, int *primeiro) {
    if (p == NULL) return 1;
    
    if (!verificaABB(p->esq, ultimo, primeiro)) return 0;
    
    if (*primeiro) {
        *primeiro = 0;
    } else {
        if (p->chave <= *ultimo) return 0;
    }
    *ultimo = p->chave;
    
    return verificaABB(p->dir, ultimo, primeiro);
}

int isABB(Node *p) {
    int ultimo = 0;
    int primeiro = 1;
    return verificaABB(p, &ultimo, &primeiro);
}

int altura(Node *p) {
    if (p == NULL) return 0;
    int alturaEsq = altura(p->esq);
    int alturaDir = altura(p->dir);
    return 1 + (alturaEsq > alturaDir ? alturaEsq : alturaDir);
}

int verificaAVL(Node *p) {
    if (p == NULL) return 1;
    
    if (!isABB(p)) return 0;
    
    int fb = altura(p->esq) - altura(p->dir);
    if (fb < -1 || fb > 1) return 0;
    
    return verificaAVL(p->esq) && verificaAVL(p->dir);
}
