//
//  arvore.h
//  EDA-trab-2
//
//  Created by Sofia Porto on 26/04/25.
//

#ifndef ARVORE_H
#define ARVORE_H

/// Definição das estruturas
typedef struct Node {
    int chave;
    struct Node *esq;
    struct Node *dir;
} Node;

typedef struct NodeFila {
    Node *node;
    struct NodeFila *prox;
} NodeFila;

typedef struct Fila {
    NodeFila *frente;
    NodeFila *tras;
} Fila;

/// Funções de Fila
Fila* criaFila(void);
int fila_vazia(Fila *q);
void enqueue(Fila *q, Node *node);
Node* dequeue(Fila *q);
void fila_libera(Fila *q);

///Funções de Árvore
Node *node_cria(int value);
Node *monta_arvore(void);
Node* monta_arvore_nivel(void);
void exibe_preordem(Node *root);
void exibe_simetrica(Node *p);
int deletamin(Node **pt);
void deleta(int x, Node **pt);
void libera_arvore(Node *root);
void troca_valor(Node *root, int antigo, int novo);

///Funções de verificação
int verificaABB(Node *p, int *ultimo, int *primeiro);
int isABB(Node *p);
int altura(Node *p);
int verificaAVL(Node *p);

#endif /* arvore_h */
